import { Component } from '@angular/core';
import { Platform, NavParams, ViewController, ToastController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Auth } from '../../providers/auth/auth';
import 'rxjs/add/operator/map';
import { Tweets } from '../../providers/tweets/tweets';

@Component({
    selector: 'my-responses',
    template: `
        <h1>My Responses</h1>
        <ion-list>
            <ion-item *ngFor="let res of myResponses">
                {{res.response}}
            </ion-item>
        </ion-list>
    `
})
export class MyResponses {
    username: any;
    public responses: any;
    constructor(public myResponses: MyResponses, public storage: Storage, public tweetService: Tweets, public authService: Auth) 
    {
      this.storage.get('username').then((value) => {
        this.username = value;
        this.tweetService.getMyResponses(this.username).then((datax) => {
          console.log('datax: ' + JSON.stringify(datax));
          this.responses = datax;
        }, (err) => { throw err; });
      });
    }
}