import { Component } from "@angular/core";
import { NavController, ModalController, LoadingController, ItemSliding } from 'ionic-angular';
import { Tweets } from '../../providers/tweets/tweets';
import { Auth } from '../../providers/auth/auth';
import { LoginPage } from '../login/login';
import { Storage } from '@ionic/storage';
import 'rxjs/add/operator/map'
import { ViewChild } from '@angular/core';
import { BaseChartDirective } from 'ng2-charts'
import { claimTweetForm } from '../../app/claimTweetForm/claimTweetForm.component';
import { MyResponses } from '../../app/myResponses/myResponses.component';
import { GetTweetsByUser } from '../../app/getTweetsByUser/getTweetsByUser.component';
import { ViewResponse } from '../../app/viewResponse/viewResponse.component';

@Component({
  selector: 'home-page',
  templateUrl: 'home.html',
  styles: ['.queue h1 { padding-left: 15px; }']
})
export class HomePage {
  @ViewChild(BaseChartDirective) chart: BaseChartDirective;
  generalQueueTotal2: Number = 5;
  loading: any;
  tweets: any;
  goodTweets: any;
  badTweets: any;
  username: any;
  whichPage: String = 'Good';
  public myResponses: any;
  public lineChartData: any[] = [];
  public lineChartDatax: any[] = [];
  public lineChartLabels:Array<any> = [];
  public lineChartLabelsx:Array<any> = [];
  public lineChartOptions:any = {
    responsive: true
  };
  public lineChartLegend:boolean = true;
  public lineChartType:string = 'line';
  public lineChartColors:Array<any> = [];
  constructor(public storage: Storage, public navCtrl: NavController, 
  public tweetService: Tweets, public modalCtrl: ModalController, 
  public authService: Auth, public loadingCtrl: LoadingController){ 
    this.storage.get('username').then((value) => {
      this.username = value;
      this.tweetService.getMyResponses(this.username).then((datax) => {
        console.log('datax: ' + JSON.stringify(datax));
        this.myResponses = datax;
      }, (err) => { throw err; });
    });
  }
  ionViewDidLoad() { this.getGeneralChart(); }
  getGeneralChart() { 
    this.tweetService.getGoodTweets(this.generalQueueTotal2).then((data) => {
      this.goodTweets = data;
      this.lineChartLabels = this.goodTweets.map((x) => { return x.text.substring(0,10) + '...'; });
      this.lineChartData = [ 
          { data: this.goodTweets.map((q) => { return (q.score) ? Number(q.score.toPrecision(3)) : 0 }), label: 'Sentiment'},
          { data: this.goodTweets.map((a) => { return (a.magnitude) ? Number(a.magnitude.toPrecision(3)) : 0 }), label: 'Magnitude' }
      ];
    }, (err) => { throw err; });
    this.tweetService.getBadTweets(this.generalQueueTotal2).then((data) => {
      this.badTweets = data;
    }, (err) => { throw err; });
  }
  unslideItem(slidingItem: ItemSliding) { 
    slidingItem.close();
  }
  claimTweet(slidingItem, tweet, user) {
    this.unslideItem(slidingItem);
    let prompt = this.modalCtrl.create(claimTweetForm, { tweet: tweet, user: user });
    prompt.present();
  }
  getResponseModal(res) { 
    let prompt = this.modalCtrl.create(ViewResponse, { res : res } );
    prompt.present();
  }
  getTweetsByUser(user) { 
    let prompt = this.modalCtrl.create(GetTweetsByUser, { user : user } );
    prompt.present();
  }
  changeGeneralQueue(value: Number): void {
    this.generalQueueTotal2 = value;
    this.getGeneralChart();
    setTimeout(() => {
      if (this.chart && this.chart.chart && this.chart.chart.config) {
        this.chart.chart.config.data.labels = this.lineChartLabels;
        this.chart.chart.config.data.datasets = this.lineChartData;
        this.chart.colors = this.lineChartColors;
        this.chart.chart.colors = this.lineChartColors;
        this.chart.chart.update();
      }
    }, 1000);
  }
  showLoader(){
    this.loading = this.loadingCtrl.create({
      content: 'Loading...'
    });
    this.loading.present();
  }
  logout(){
    this.authService.logout();
    this.navCtrl.setRoot(LoginPage);
  }
}